import subprocess,sys
def install_dependencies():
    """Install required dependencies for packaging and uploading."""
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "setuptools", "wheel", "twine", "keyring"])
install_dependencies()    
import keyring

# Store the API token for Test PyPI
#keyring.set_password('https://upload.pypi.org/legacy/', '__token__', 'pypi-AgEIcHlwaS5vcmcCJGMxN2Q3NWVlLTllNzQtNGRhMC04ODc1LTZhODdkODYwNzczMAACKlszLCJkZTcyZjIwNC0yMDkxLTRiMjQtYmFhOC01YzhlMTVhMDBkMzciXQAABiDPY1guFfdfKiqUJhvZ1yu5HlaBdQmmZao8_b0n-V_CcQ')
#twine upload dist/* --repository-url https://upload.pypi.org/legacy/


#for test pypi

#import keyring

# Store the API token for Test PyPI
keyring.set_password('https://upload.pypi.org/legacy/', '__token__', 'pypi-AgEIcHlwaS5vcmcCJDM4YTExOTViLTRmNWMtNDM3Yy1hNDRlLTAwMThjYzZhODdmMQACKlszLCI3YjVhOGU3YS04NWNhLTRkZmItODM0ZC1kMWFiMDljNzM0YjAiXQAABiDLS0spy2xETmpqdgMLnGEXisbGHQx10qoxZCK_YsZO5Q')
import subprocess
import sys
import os



def clean_dist_folder():
    """Remove old distribution files."""
    dist_dir = os.path.join(os.getcwd(), "dist")
    if os.path.exists(dist_dir):
        for root, dirs, files in os.walk(dist_dir):
            for file in files:
                os.remove(os.path.join(root, file))
            for dir_ in dirs:
                os.rmdir(os.path.join(root, dir_))
        os.rmdir(dist_dir)

def build_package():
    """Build the source distribution and wheel."""
    subprocess.check_call([sys.executable, "setup.py", "sdist", "bdist_wheel"])

def upload_to_test_pypi():
    """Upload the package to Test PyPI."""
    subprocess.check_call([sys.executable, "-m", "twine", "upload", "dist/*", "--repository-url", "https://upload.pypi.org/legacy/"])

def main():
    """Main function to automate the entire process."""
    clean_dist_folder()
    build_package()
    upload_to_test_pypi()

if __name__ == "__main__":
    main()

